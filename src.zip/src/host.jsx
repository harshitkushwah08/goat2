const BASE_URL = "http://localhost:5173/"
export default BASE_URL;